# nodejs-loopback-scaffold

This project is originally generated using `lb4` command from `@loopback/cli`. See [Getting started with LoopBack 4](https://loopback.io/doc/en/lb4/Getting-started.html) for more details.

It has been slightly tailored as a template for `appsody`.

[![LoopBack](<https://github.com/strongloop/loopback-next/raw/master/docs/site/imgs/branding/Powered-by-LoopBack-Badge-(blue)-@2x.png>)](http://loopback.io/)
